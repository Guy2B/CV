param(
  [string]$Folder = "."
)

$ErrorActionPreference = "Stop"

function Read-Utf8([string]$Path) {
  return [System.IO.File]::ReadAllText((Resolve-Path $Path), [System.Text.Encoding]::UTF8)
}

function Write-Utf8([string]$Path, [string]$Text) {
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText((Resolve-Path $Path), $Text, $utf8NoBom)
}

$impressum = Join-Path $Folder "impressum.html"
$privacy   = Join-Path $Folder "privacy.html"

if (!(Test-Path $impressum) -or !(Test-Path $privacy)) {
  throw "Place this script in the CV website folder, or pass -Folder with the folder containing impressum.html and privacy.html."
}

$imp = Read-Utf8 $impressum
$pri = Read-Utf8 $privacy

# Safety: preserve the user's real postal address. If a placeholder is still present,
# do not remove the publication warning automatically.
$hasPlaceholder = ($imp -match "\[POSTANSCHRIFT") -or ($pri -match "\[POSTANSCHRIFT")

# 1) Remove telephone from legal pages; keep email and postal address.
$imp = [regex]::Replace($imp, '<br>\s*Telefon:\s*[^<]*', '', 'IgnoreCase')
$pri = [regex]::Replace($pri, '<br>\s*Telefon:\s*[^<]*', '', 'IgnoreCase')

# 2) Remove the draft warning only when the real address is already present.
if (-not $hasPlaceholder) {
  $imp = [regex]::Replace($imp, '<div class="notice">.*?</div>\s*', '', 'Singleline,IgnoreCase')
  $pri = [regex]::Replace($pri, '<div class="notice">.*?</div>\s*', '', 'Singleline,IgnoreCase')
}

# 3) Simplify the Analytics section: no measurement ID, no event inventory.
$analyticsSection = @'
<section>
<h2>3. Google Analytics und Einwilligung</h2>
<p>Diese Website verwendet Google Analytics ausschließlich nach Ihrer ausdrücklichen Einwilligung. Sie können Ihre Entscheidung jederzeit über die <button class="analytics-settings-link" data-analytics-settings>Datenschutz-Einstellungen</button> ändern.</p>
<p>Weitere Informationen zur Datenverarbeitung durch Google finden Sie in der <a href="https://policies.google.com/privacy" rel="noopener" target="_blank">Datenschutzerklärung von Google</a>.</p>
</section>
'@

$pri = [regex]::Replace(
  $pri,
  '<section>\s*<h2>3\. Google Analytics und Einwilligung</h2>.*?</section>',
  $analyticsSection,
  'Singleline,IgnoreCase'
)

# 4) Remove draft/internal notes that should not be visible on a premium published site.
$imp = [regex]::Replace(
  $imp,
  '<section>\s*<h2>Hinweis</h2>.*?</section>\s*',
  '',
  'Singleline,IgnoreCase'
)

$pri = [regex]::Replace(
  $pri,
  '<p class="meta">Diese Datenschutzerklärung beschreibt die technische Fassung.*?</p>\s*',
  '',
  'Singleline,IgnoreCase'
)

Write-Utf8 $impressum $imp
Write-Utf8 $privacy $pri

Write-Host ""
Write-Host "Premium legal cleanup applied:" -ForegroundColor Green
Write-Host "  - phone removed from Impressum and Privacy"
Write-Host "  - Analytics details simplified"
Write-Host "  - internal/draft legal notes removed"
if ($hasPlaceholder) {
  Write-Host "  - IMPORTANT: postal-address placeholder detected; publication warning was kept." -ForegroundColor Yellow
} else {
  Write-Host "  - postal address preserved exactly as it was"
  Write-Host "  - pre-publication warning removed"
}
Write-Host ""
