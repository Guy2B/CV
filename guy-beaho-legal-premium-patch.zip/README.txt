GUY BEAHO — PREMIUM LEGAL CLEANUP

Purpose
-------
This patch updates your CURRENT local impressum.html and privacy.html,
so your already-entered postal address is preserved.

Changes
-------
- Removes the telephone number from Impressum and Privacy.
- Keeps the postal address and contact@guybeaho.com.
- Simplifies the Google Analytics disclosure:
  no measurement ID and no event-by-event details.
- Removes the internal "Hinweis" / draft wording.
- Removes the yellow pre-publication warning ONLY if no address placeholder remains.

Windows
-------
1. Copy apply-premium-legal-cleanup.ps1 into your current CV repository folder
   (the folder containing impressum.html and privacy.html).
2. Open PowerShell in that folder.
3. Run:
   powershell -ExecutionPolicy Bypass -File .\apply-premium-legal-cleanup.ps1
4. Open impressum.html and privacy.html locally and verify.
5. Commit/push with GitHub Desktop.

The script does NOT alter your postal address.
